/**
 * This file is ArcYun's property. It contains ArcYun's trade secret, proprietary and 		
 * confidential information. 
 * 
 * The information and code contained in this file is only for authorized ArcYun employees 
 * to design, create, modify, or review.
 * 
 * DO NOT DISTRIBUTE, DO NOT DUPLICATE OR TRANSMIT IN ANY FORM WITHOUT PROPER AUTHORIZATION.
 * 
 * If you are not an intended recipient of this file, you must not copy, distribute, modify, 
 * or take any action in reliance on it. 
 * 
 * If you have received this file in error, please immediately notify ArcYun and 
 * permanently delete the original and any copy of any file and any printout thereof.
 *
 * Change History:
 * 2017-10-17 Jarvis Bao ---Created
*/
namespace cpp com.arcyun.thrift.LightECE
namespace java com.arcyun.thrift.LightECE

typedef i32 Integer
typedef i64 long

struct Field{
	1: string Name,
	2: binary Value
}

struct Header{
	1: string AppID,    //AppID
	2: long Timestamp,  //时间戳
	3: string Noncestr, //随机字符串
	4: string Signature //数字签名
}

struct Request{
	1: Header header,
	2: string serviceName,
	3: string session,  //Session名字
	4: string clientid, //客户ID
	5: long requesttime,
	6: string requestid,
	7: list<Field> fields
}

struct Response{
	1: string serviceName,
	2: string session,
	3: string clientid,
	4: string responseid,
	5: long requesttime,
	6: long responsetime,
	7: string requestid,
	8: i32 code,
	9: string message,
	10: list<Field> fields
}

service ECEService{
	Response onRequest(1:string action, 2:Request request)
}